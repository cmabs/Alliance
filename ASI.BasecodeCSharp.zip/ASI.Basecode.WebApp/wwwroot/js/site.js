﻿let dpicn = document.querySelector(".dpicn");
let dropdown = document.querySelector(".dropdown");

dpicn.addEventListener("click", () => {
    dropdown.classList.toggle("dropdown-open");
})